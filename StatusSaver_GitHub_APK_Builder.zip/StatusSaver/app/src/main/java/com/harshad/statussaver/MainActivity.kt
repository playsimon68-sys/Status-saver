package com.harshad.statussaver

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val pickFolder = 41
    private var statusFolder: DocumentFile? = null
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val saved = getPreferences(MODE_PRIVATE).getString("tree", null)
        if (saved != null) {
            try {
                val uri = Uri.parse(saved)
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                statusFolder = DocumentFile.fromTreeUri(this, uri)
                scanStatuses()
            } catch (_: Exception) {
                statusText.text = "Choose your WhatsApp .Statuses folder to begin."
            }
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFF101412.toInt())
        }
        val title = TextView(this).apply {
            text = "Status Saver"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "Save statuses you've viewed"
            textSize = 14f
            setTextColor(0xFFB7C5BC.toInt())
            setPadding(0, 5, 0, 22)
        }
        val choose = Button(this).apply {
            text = "Choose WhatsApp Status Folder"
            setOnClickListener { openFolderPicker() }
        }
        val refresh = Button(this).apply {
            text = "Refresh statuses"
            setOnClickListener { scanStatuses() }
        }
        statusText = TextView(this).apply {
            text = "First, choose the hidden .Statuses folder."
            textSize = 14f
            setTextColor(0xFFE0E8E2.toInt())
            setPadding(0, 14, 0, 14)
        }
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(title)
        root.addView(subtitle)
        root.addView(choose)
        root.addView(refresh)
        root.addView(statusText)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openFolderPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(intent, pickFolder)
    }

    @Deprecated("Use Activity Result APIs in future updates")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFolder && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                getPreferences(MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
                statusFolder = DocumentFile.fromTreeUri(this, uri)
                scanStatuses()
            } catch (e: Exception) {
                statusText.text = "Folder permission could not be saved. Please try again."
            }
        }
    }

    private fun scanStatuses() {
        list.removeAllViews()
        val folder = statusFolder
        if (folder == null || !folder.isDirectory) {
            statusText.text = "Choose the .Statuses folder first."
            return
        }
        val files = folder.listFiles().filter {
            it.isFile && (it.name?.lowercase(Locale.ROOT)?.endsWith(".jpg") == true ||
                    it.name?.lowercase(Locale.ROOT)?.endsWith(".jpeg") == true ||
                    it.name?.lowercase(Locale.ROOT)?.endsWith(".png") == true ||
                    it.name?.lowercase(Locale.ROOT)?.endsWith(".webp") == true ||
                    it.name?.lowercase(Locale.ROOT)?.endsWith(".mp4") == true)
        }.sortedByDescending { it.lastModified() }

        statusText.text = if (files.isEmpty())
            "No statuses found. View a WhatsApp status, then refresh."
        else "${files.size} status file(s) found"

        files.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 12, 8, 12)
            }
            val name = TextView(this).apply {
                text = file.name ?: "Status"
                textSize = 13f
                setTextColor(0xFFFFFFFF.toInt())
                maxLines = 2
            }
            val save = Button(this).apply {
                text = "Save"
                setOnClickListener { saveToGallery(file) }
            }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(save)
            list.addView(row)
            val line = View(this).apply { setBackgroundColor(0xFF29332D.toInt()) }
            list.addView(line, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun saveToGallery(file: DocumentFile) {
        try {
            val name = file.name ?: "status_${System.currentTimeMillis()}"
            val isVideo = name.lowercase(Locale.ROOT).endsWith(".mp4")
            val mime = if (isVideo) "video/mp4" else when {
                name.endsWith(".png", true) -> "image/png"
                name.endsWith(".webp", true) -> "image/webp"
                else -> "image/jpeg"
            }
            val collection = if (isVideo) MediaStore.Video.Media.getContentUri("external")
                             else MediaStore.Images.Media.getContentUri("external")
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                if (Build.VERSION.SDK_INT >= 29)
                    put(MediaStore.MediaColumns.RELATIVE_PATH,
                        if (isVideo) "Movies/Status Saver" else "Pictures/Status Saver")
            }
            val destination = contentResolver.insert(collection, values)
                ?: throw IllegalStateException("Could not create gallery file")
            contentResolver.openInputStream(file.uri).use { input ->
                contentResolver.openOutputStream(destination).use { output ->
                    if (input == null || output == null) throw IllegalStateException("File unavailable")
                    input.copyTo(output)
                }
            }
            Toast.makeText(this, "Saved to your gallery", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not save this status", Toast.LENGTH_LONG).show()
        }
    }
}
