# Status Saver (Android)

A small, local-only Android app that copies already-viewed WhatsApp status media into the phone gallery.

## Build an APK automatically with GitHub Actions (phone-friendly)

1. Sign in to [GitHub](https://github.com/) and create a new **public or private repository** named `StatusSaver`.
2. Download and extract this ZIP on your phone.
3. Upload the **contents inside the `StatusSaver` folder** to the root of that GitHub repository. Make sure `.github/workflows/build-apk.yml` is included. If using GitHub's mobile website, enable showing hidden files in your file manager so the `.github` folder is not missed.
4. Open the repository on GitHub and select **Actions**. If prompted, allow workflows for the repository.
5. The workflow starts automatically after the files are pushed to the `main` branch. You can also select **Build Status Saver APK** → **Run workflow**.
6. Open the completed workflow run, scroll to **Artifacts**, and download `StatusSaver-debug-apk`. Extract that downloaded artifact ZIP to get `app-debug.apk`.
7. Open the APK on your phone and allow installation from that source if Android asks.

The workflow uses GitHub-hosted Ubuntu runners, Java 17, Android SDK, and Gradle 8.9. It builds a **debug APK**; it is suitable for testing, not a Play Store release. GitHub Actions usage is subject to your account's included minutes and storage limits.

## Build locally

Open this project in Android Studio or a compatible Android IDE, sync Gradle, then run `assembleDebug`.

## First launch

1. In WhatsApp, open the status you want to save.
2. Open Status Saver and tap **Choose WhatsApp Status Folder**.
3. Browse to `Android/media/com.whatsapp/WhatsApp/Media/.Statuses`.
   - If you use WhatsApp Business, the folder is usually under `Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses`.
   - The `.Statuses` folder may be hidden. Enable “Show hidden files” in the picker if offered.
4. Grant read access, then tap Refresh statuses.
5. Tap Save beside an item. Files are copied into Pictures/Status Saver or Movies/Status Saver.

## Notes

- This app does not download statuses from WhatsApp servers or bypass privacy settings. It reads only media already present on-device and accessible after you grant folder access.
- Android document pickers differ by manufacturer. If the picker blocks access to the folder, this build cannot bypass that restriction.
- Use only for statuses you have permission to save or share.
